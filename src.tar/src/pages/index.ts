export { CommunicationPage } from "./communicationPage";
export { StatisticsPage } from "./statisticsPage";
export { TaskManagmentPage } from "./taskManagmentPage";
